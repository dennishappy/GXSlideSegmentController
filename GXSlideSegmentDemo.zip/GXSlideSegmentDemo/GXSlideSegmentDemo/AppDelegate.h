//
//  AppDelegate.h
//  GXSlideSegmentDemo
//
//  Created by  GuoShengyong on 16/4/5.
//  Copyright © 2016年 bql. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

